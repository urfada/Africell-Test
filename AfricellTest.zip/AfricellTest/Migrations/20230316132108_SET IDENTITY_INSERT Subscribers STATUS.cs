﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AfricellTest.Migrations
{
    /// <inheritdoc />
    public partial class SETIDENTITY_INSERTSubscribersSTATUS : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
