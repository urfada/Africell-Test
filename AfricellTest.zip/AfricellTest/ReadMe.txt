Once you run the program, the webpage may say the localhost cannot be found so you are required to add "/swagger" to the link
