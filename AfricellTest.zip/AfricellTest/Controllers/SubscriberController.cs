using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AfricellTest.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AfricellTest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SubscriberController : ControllerBase
    {
        private readonly ILogger<SubscriberController> _logger;
        private readonly ApplicationDbContext _context;

        public SubscriberController(ILogger<SubscriberController> logger, ApplicationDbContext context)
            {
                _logger = logger;
                _context = context;
            }

        // GET: api/subscriber
        [HttpGet]
            public async Task<ActionResult<IEnumerable<Subscriber>>> GetSubscribers()
            {
                
                if (_context.Subscribers == null)
                    {
                        return NotFound();
                    }
                 return await _context.Subscribers.ToListAsync();
            }

        // GET: api/subscriber/5
        [HttpGet("{id}")]
            public async Task<ActionResult<Subscriber>> GetSubscriber(int id)
            {
                if (_context.Subscribers == null)
                {
                    return NotFound();
                }
                var subscriber = await _context.Subscribers.FindAsync(id);

                if (subscriber == null)
                {
                    return NotFound();
                }

                return subscriber;
            }

        // PUT: api/subscriber/5
        //Similar to post but used to update an entire entity. Basically an update method
        [HttpPut("{id}")]
        public async Task<IActionResult> PutSubscriber(int id, Subscriber subscriber)
        {
            if (id != subscriber.Id)
            {
                return BadRequest();
            }

            _context.Entry(subscriber).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SubscriberExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/subscriber
        [HttpPost]
            public async Task<ActionResult<Subscriber>> PostSubscriber(Subscriber subscriber)
            {
                if (_context.Subscribers == null)
                    {
                        return Problem("Entity set 'TodoContext.TodoItems'  is null.");
                    }
                _context.Subscribers.Add(subscriber);
                await _context.SaveChangesAsync();

                return CreatedAtAction(nameof(GetSubscriber), new { id = subscriber.Id }, subscriber);
            }

        // DELETE: api/subscriber/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSubscriber(int id)
            {   
                 if (_context.Subscribers == null)
                {
                    return NotFound();
                }
                var subscriber = await _context.Subscribers.FindAsync(id);
                if (subscriber == null)
                {
                    return NotFound();
                }

                _context.Subscribers.Remove(subscriber);
                await _context.SaveChangesAsync();

                return NoContent();
            }

        // GET: api/subscriber/{msisdn}/balance
        [HttpGet("{msisdn}/balance")]
        public async Task<ActionResult<double>> GetSubscriberBalance(string msisdn)
            {
                // fetches the subscriber balance from an external API using the MSISDN.
                // returns a randon value from 0-1000
                var balance = new Random().NextDouble() * 1000;

                return balance;
            }

        private bool SubscriberExists(int id)
        {
            return (_context.Subscribers?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}